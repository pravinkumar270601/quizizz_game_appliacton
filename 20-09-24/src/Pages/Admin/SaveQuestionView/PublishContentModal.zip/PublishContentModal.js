
import React, { useState, useEffect } from 'react';
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    IconButton,
    Button,
    Typography,
    Switch,
    FormControl,
    RadioGroup,
    FormControlLabel,
    Radio,
    TextField,
    Grid,
    Tooltip,
    
} from '@mui/material';
import { Close as CloseIcon, Info ,AccessTime, Label} from '@mui/icons-material';
import { LuRectangleHorizontal } from "react-icons/lu";
import { Formik, Form, Field } from 'formik';
import { ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { InputLabel, Select, MenuItem, FormHelperText, Box } from '@mui/material';
import ErrorIcon from '@mui/icons-material/Error';
import BookIcon from '@mui/icons-material/MenuBook';
import SchoolIcon from '@mui/icons-material/School';
import LanguageIcon from '@mui/icons-material/Language';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { Select as FormikSelect } from 'formik-material-ui';



const PublishContentModal = ({ open, onClose }) => {
    const questionSeconds = [
        { label: "5 Seconds", value: "5seconds" },
        { label: "10 Seconds", value: "10seconds" },
        // ...other options
      ];

    const validationSchema = Yup.object({
        name: Yup.string()
            .min(4, 'Name should be at least 4 characters long')
            .required('Name is required'),
        subject: Yup.string().required('Please select the subject'),
        grade: Yup.string().required('Please select the grade'),
    });


    return (
        <Dialog
            open={open}
            onClose={onClose}
            fullWidth
            maxWidth="md"
            sx={{
                overflowX: 'auto',
                width: "100%",
                '& .MuiPaper-root': {
                    maxWidth: "650px",
                    '& .MuiDialog-paper': {
                        overflowY: 'visible',
                        width: '70%',
                        maxWidth: "300px",
                        margin: 'auto',
                        borderRadius: 2,
                        background: "white",
                    }
                },
                '& .MuiDialog-container': {
                    height: 'auto',
                },
                '& .MuiDialog-paper': { borderRadius: 2 }
            }}
        >
            <IconButton
                aria-label="Close"
                onClick={() => {
                    onClose();

                }}
                sx={{ position: 'absolute', top: 8, right: 8, color: 'text.secondary' }}
            >
                <CloseIcon />
            </IconButton>

            <DialogTitle sx={{ display: 'flex', alignItems: 'center' }}>
                <Grid
                    item
                    sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: 40,
                        height: 40,
                        borderRadius: '50%',
                        backgroundColor: 'rgb(237 230 246)',
                        color: 'rgb(136 84 192)',
                        marginRight: 1,
                    }}
                >
                    <LuRectangleHorizontal />
                </Grid>
                <Typography variant="h6" sx={{ fontWeight: 'bold', fontSize: '17px' }}>
                    Quizz Settings
                </Typography>
            </DialogTitle>
            <DialogContent dividers sx={{ padding: 4 }}>
                <Formik
                    initialValues={{ name: '', subject: '', grade: '', language: 'English' }}
                    validationSchema={validationSchema}
                    onSubmit={(values) => {
                        console.log('Form Values:', values);
                    }}
                >
                    {({ handleChange, values, errors, touched }) => (
                        <Form>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, width: '400px', margin: 'auto' }}>

                                {/* Name Input */}
                                <FormControl fullWidth margin="normal">
                                    <Field
                                        as={TextField}
                                        label="Name"
                                        name="name"
                                        variant="outlined"
                                        placeholder="Untitled Quiz"
                                        helperText={<ErrorMessage name="name" />}
                                        error={touched.name && Boolean(errors.name)}
                                        InputProps={{
                                            endAdornment: touched.name && errors.name && (
                                                <IconButton edge="end">
                                                    <ErrorIcon color="error" fontSize="small" />
                                                </IconButton>
                                            ),
                                        }}
                                    />
                                </FormControl>

                                {/* Subject Dropdown */}
                                <FormControl fullWidth margin="normal" error={touched.subject && Boolean(errors.subject)}>
                                    <InputLabel>Subject</InputLabel>
                                    <Field
                                        as={Select}
                                        name="subject"
                                        value={values.subject}
                                        onChange={handleChange}
                                        endAdornment={<ArrowDropDownIcon />}
                                    >
                                        <MenuItem value="Mathematics">
                                            <BookIcon /> Mathematics
                                        </MenuItem>
                                        <MenuItem value="English">
                                            <BookIcon /> English
                                        </MenuItem>
                                        {/* Add more subjects as needed */}
                                    </Field>
                                    <FormHelperText><ErrorMessage name="subject" /></FormHelperText>
                                </FormControl>

                                {/* Grade Dropdown */}
                                
                                <Field
                                    component={FormikSelect}
                                    name="timeLimit"
                                    variant="outlined"
                                  
                                    sx={{
                                        height: 28,
                                        pl: 1,
                                        pr: 1,
                                        color: 'black',
                                        fontSize: '12px',
                                        fontWeight: '500',
                                        bgcolor: "white",
                                        border: "1px solid #0909090d",
                                        '& .MuiSelect-select': {
                                            padding: 0,
                                        },
                                    }}
                                    startAdornment={<AccessTime fontSize="8px" sx={{ mr: 1 }} />}
                                >
                                    {questionSeconds.map((type) => (
                                        <MenuItem key={type.value} value={type.value}>
                                            {type.label}
                                        </MenuItem>
                                    ))}
                                </Field>

                                {/* Language Selector */}
                                <FormControl fullWidth margin="normal">
                                    <InputLabel>Language</InputLabel>
                                    <Field
                                        as={Select}
                                        name="language"
                                        value={values.language}
                                        onChange={handleChange}
                                        endAdornment={<ArrowDropDownIcon />}
                                    >
                                        <MenuItem value="English">
                                            <LanguageIcon /> English
                                        </MenuItem>
                                        <MenuItem value="Spanish">
                                            <LanguageIcon /> Spanish
                                        </MenuItem>
                                        {/* Add more languages as needed */}
                                    </Field>
                                </FormControl>

                                {/* Submit Button */}
                                <Box sx={{ mt: 2 }}>
                                    <button type="submit">Submit</button>
                                </Box>
                            </Box>
                        </Form>
                    )}
                </Formik>

            </DialogContent>
            <DialogActions sx={{ padding: 2, paddingRight: 4 }}>
                <Button
                    onClick={() => {
                        onClose();

                    }}
                    variant="text"
                    sx={{
                        background: "rgb(249 249 249)",
                        color: "black",
                        '&:hover': {
                            backgroundColor: 'rgb(249 249 249)',
                            color: "black",
                        },
                    }}
                >
                    Cancel
                </Button>

                <Button type='submit' variant="contained"
                    sx={{
                        background: "rgb(136 84 192)",
                        color: "white",
                        '&:hover': {
                            backgroundColor: 'rgb(136 84 192)',
                            color: "white",
                        },
                    }}>
                    Save
                </Button>
            </DialogActions>

        </Dialog>
    );
};

export default PublishContentModal;
