// import logo from './logo.svg';
// import './App.css';
// import Sidebar from './Components/SideNav/Sidebar';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Header from './Components/SideNav/Header';
// import Layout from './Components/Layout/Layout';
// import QuizEditor from './Pages/Admin/Create/QuizEditor';

// function App() {
//   return (
//     <div className="App">
//       <Router>
//         {/* <Sidebar /> */}
//         {/* <Header /> */}
//         <Layout />

//         <Routes>
//           {/* Your routes here */}
//         </Routes>
//         {/* <QuizEditor /> */}
//       </Router>
//     </div>
//   );
// }

// export default App;


import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './Components/Layout/Layout';
import './App.css';
import QuizEditor from './Pages/Admin/Create/QuizEditor';
import CreateNewActivity from './Pages/Admin/Create/CreateNewActivity';
import QuestionEditor from './Pages/Admin/Create/QuestionEditor';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import SaveQuestionView from './Pages/Admin/SaveQuestionView/SaveQuestionView';

const theme = createTheme();
function App() {
  return (
    <div className="App">
      <ThemeProvider theme={theme}>


        <Router>
          <Routes>
            {/* Main layout which contains sidebar, header, etc. */}

            <Route path="/*" element={<Layout />} />
            {/* <Route path="/quizeditor" element={<QuizEditor />} /> */}
            <Route path="/quizeditor" element={<CreateNewActivity />} />
            <Route path="/question-editor" element={<QuestionEditor />} />
            <Route path="/importworksheet" element={<QuizEditor />} />
            <Route path="/savequetion" element={<SaveQuestionView />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </div>
  );
}

export default App;
