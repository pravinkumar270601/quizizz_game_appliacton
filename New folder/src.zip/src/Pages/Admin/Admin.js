import { Box } from '@mui/material'
import React from 'react'
import SearchComponent from './SearchComponent'

const Admin = () => {
  return (
    <div>
        <Box>
            <SearchComponent />
        </Box>
    </div>
  )
}

export default Admin